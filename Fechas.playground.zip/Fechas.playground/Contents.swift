//: Playground - noun: a place where people can play

import UIKit

let fecha  = NSDate()
let formato = NSDateFormatter()


// Formatos predefinidos

print ("Formatos Predefinidos de Fechas")
formato.timeStyle = NSDateFormatterStyle.NoStyle
formato.dateStyle = NSDateFormatterStyle.ShortStyle
print ("Short date style => " + formato.stringFromDate(fecha))

formato.dateStyle = NSDateFormatterStyle.MediumStyle
print ("Medium date style => " + formato.stringFromDate(fecha))

formato.dateStyle = NSDateFormatterStyle.LongStyle
print ("Long date style => " + formato.stringFromDate(fecha))

formato.dateStyle = NSDateFormatterStyle.FullStyle
print ("Full date style => " + formato.stringFromDate(fecha))

print ("\nFormatos Predefinidos de Horas")
formato.dateStyle = NSDateFormatterStyle.NoStyle
formato.timeStyle = NSDateFormatterStyle.ShortStyle
print ("Short time style => " + formato.stringFromDate(fecha))

formato.timeStyle = NSDateFormatterStyle.MediumStyle
print ("Medium time style => " + formato.stringFromDate(fecha))

formato.timeStyle = NSDateFormatterStyle.LongStyle
print ("Long time style => " + formato.stringFromDate(fecha))

formato.timeStyle = NSDateFormatterStyle.FullStyle
print ("Full time style => " + formato.stringFromDate(fecha))

print ("\nFormatos Definidos por el programador")
// Escribe los estatutos necesarios para obtener la fecha/hora con los siguientes formatos.
// Se revisará con un comparador de texto, asegúrate que aparece igual.


// 1. Wed, 17 Aug
formato.dateFormat = "EEE, dd MMM"
print (formato.stringFromDate(fecha))

// 2. Wednesday August 17
formato.dateFormat = "EEEE MMMM dd"
print (formato.stringFromDate(fecha))

// 3. 8/17/16, 12:45 PM
formato.dateFormat = "M/dd/yy, hh:mm a"
print (formato.stringFromDate(fecha))

// 4. 17 / Aug / 2016 ---  12 : 45 : 12
formato.dateFormat = "dd / MMM / yyyy ---  hh : mm : ss"
print (formato.stringFromDate(fecha))

// 5. Aug of 2016
formato.dateFormat = "MMM 'of' yyyy"
print (formato.stringFromDate(fecha))

// 6. 17 / 08 / 16  at 12:45 PM
formato.dateFormat = "dd / MM / yy  'at' hh:mm a"
print (formato.stringFromDate(fecha))

// 7. Dia siguiente: Thursday August 18
formato.dateFormat = "'Dia siguiente:' EEEE MMMM dd"
print (formato.stringFromDate(fecha.dateByAddingTimeInterval(60 * 60 * 24)))

// 8. Dia anterior: Tuesday August 16
formato.dateFormat = "'Dia anterior:' EEEE MMMM dd"
print (formato.stringFromDate(fecha.dateByAddingTimeInterval(-(60 * 60 * 24))))

// 9. Semana siguiente: Wednesday August 24
formato.dateFormat = "'Semana siguiente:' EEEE MMMM dd"
print (formato.stringFromDate(fecha.dateByAddingTimeInterval(60 * 60 * 24 * 7)))

// 10. Semana anterior: Wednesday August 10
formato.dateFormat = "'Semana anterior:' EEEE MMMM dd"
print (formato.stringFromDate(fecha.dateByAddingTimeInterval(-(60 * 60 * 24 * 7))))
